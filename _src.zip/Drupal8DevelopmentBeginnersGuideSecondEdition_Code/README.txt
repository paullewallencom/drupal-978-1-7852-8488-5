This code bundle has code of chapters 5 and 6 and code of other chapters can be taken from the chapters itself.



To follow the examples in this book, you'll need a computer on which you can set up your own development environment with a number of useful tools. All these tools are either open source or have free equivalents. The PhpStorm IDE mentioned in Chapter 1, Setting Up a Drupal Development Environment, is a proprietary and fairly expensive piece of software, but you could also use NetBeans or Eclipse as alternative IDEs, as they have comparable features. 

You're also going to need an Internet connection. Many of the examples in this book rely on external services such as GitHub or PuPHPet and you'll have to do some fairly large downloads if you're installing some of the recommended software packages from scratch.